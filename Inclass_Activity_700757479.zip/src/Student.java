import java.util.ArrayList;
import java.util.List;

public class Student {
    private String studentName;
    private String studentId;
    private List<addcourse> courses;

    public Student(String studentName, String studentId) {
        this.studentName = studentName;
        this.studentId = studentId;
        this.courses = new ArrayList<>();
    }

    public void addCourse(addcourse course) {
        courses.add(course);
    }

    public void removeCourse(addcourse course) {
        courses.remove(course);
    }

    public List<addcourse> getCourses() {
        return courses;
    }

    // Getters and Setters
    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    @Override
    public String toString() {
        return studentName + " (" + studentId + ")";
    }
}
