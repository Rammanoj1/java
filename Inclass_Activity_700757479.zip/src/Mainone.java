public class Mainone {
    public static void main(String[] args) {
        Student student = new Student("RAMCHARAN", "700757479");

        addcourse course1 = new addcourse("Computer Science", "CS5600");
        addcourse course2 = new addcourse("Data Structures", "CS102");

        student.addCourse(course1);
        student.addCourse(course2);

        System.out.println("Courses registered for " + student.getStudentName() + ":");
        for (addcourse course : student.getCourses()) {
            System.out.println(course);
        }

        // Add a new course dynamically
        addcourse course3 = new addcourse("Algorithms", "CS103");
        student.addCourse(course3);

        System.out.println("\nAfter adding a new course:");
        for (addcourse course : student.getCourses()) {
            System.out.println(course);
        }

        // Remove a course
        student.removeCourse(course2);

        System.out.println("\nAfter removing a course:");
        for (addcourse course : student.getCourses()) {
            System.out.println(course);
        }
    }
}
