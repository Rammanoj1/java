public class Registered {
    public static void main(String[] args) {
        Student student = new Student("RAMCHARAN", "700757479");

        addcourse course1 = new addcourse("Big Data", "CS5400");
        addcourse course2 = new addcourse("cloud computing", "CS150");

        student.addCourse(course1);
        student.addCourse(course2);

        displayRegisteredCourses(student);

        // Add a new course dynamically
        addcourse course3 = new addcourse("java", "CS110");
        student.addCourse(course3);

        System.out.println("\nAfter adding a new course:");
        displayRegisteredCourses(student);

        // Remove a course
        student.removeCourse(course2);

        System.out.println("\nAfter removing a course:");
        displayRegisteredCourses(student);
    }

    public static void displayRegisteredCourses(Student student) {
        System.out.println("Courses registered for " + student.getStudentName() + ":");
        for (addcourse course : student.getCourses()) {
            System.out.println(course);
        }
    }
}
