import java.util.LinkedList;
import java.util.Queue;

public class addnewticket {
    private Queue<String> tickets;

    public addnewticket() {
        this.tickets = new LinkedList<>();
    }

    public void addTicket(String ticket) {
        tickets.add(ticket);
        System.out.println("Ticket '" + ticket + "' added.");
    }

    public void processTicket() {
        if (!tickets.isEmpty()) {
            String processedTicket = tickets.poll();
            System.out.println("Ticket '" + processedTicket + "' processed.");
        } else {
            System.out.println("No tickets to process.");
        }
    }

    public void viewTickets() {
        if (!tickets.isEmpty()) {
            System.out.println("Pending tickets:");
            for (String ticket : tickets) {
                System.out.println(ticket);
            }
        } else {
            System.out.println("No pending tickets.");
        }
    }

    public static void main(String[] args) {
        addnewticket ticketSystem = new addnewticket();
        ticketSystem.addTicket("Ticket 1");
        ticketSystem.addTicket("Ticket 2");
        ticketSystem.viewTickets();
        ticketSystem.processTicket();
        ticketSystem.viewTickets();
        ticketSystem.processTicket();
        ticketSystem.viewTickets();
    }
}